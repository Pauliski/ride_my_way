# ***Ride-My-Way - Drivers & Passenger App*** #
**simple Driver - Passenger app created with react.js**

## Table of Content ##
- Passengers Account
- Drivers Account
- Passangers ride request
- Drivers ride accept/rejection
- Real time notification on request accepted/declined
