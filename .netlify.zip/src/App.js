// import Homepage from './Homepage';
import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import { Route, Switch } from "react-router-dom";
import Homepage from "./Homepage";
import SidebarContextProvider from "./Context/SidebarContext";
import Login from "./Login";
import Dashboard from "./Dashboard";
import Signup from "./Signup";
import ThemeContextProvider from "./Context/ThemeContext";
import AvailableRide from "./AvailableRide";
import RecentTrip from "./RecentTrip";
import DriverNotification from "./DriverNotification";
import DriverDashboard from "./DriverDashboard";
import Check from "./Check";
import Chart from "./Chart";
import SideIcon from "./SideIcon";
import Card from "./Card";
import RecentTemplate from "./RecentTemplate";
import DriverSignup from "./DriverSignup";
import SignupUpload from "./SignupUpload";
import {AuthContextProvider} from './Context/AuthContext'
import ProtectedRoute from "./validation/ProtectedRoute";
import EditProfile from "./pages/EditProfile/EditProfile";
import Upload from "./pages/ImageUpload/ImageUpload";
import Offer from "./components/Offer/Offer";
import DisplayOffer from "./components/DisplayOffer/DisplayOffer";
import AllOffers from "./pages/AllOffers/AllOffers";
import DriverRegister from "./components/DriverRegister/DriverRegister";

function App() {
  return (
    
     

     <Switch>
       <ThemeContextProvider>
      <Route component={Homepage} exact path="/" />
      <Route component={Homepage} path="/home" />
      <Route component={Login} path="/login" />
      <Route component={Signup} path="/signup" />
      <ProtectedRoute component={Dashboard} path="/notification" />
      {/* <ProtectedRoute component={AvailableRide}  path='/availablerides' /> */}
      <ProtectedRoute component={AvailableRide}  path="/dashboard" />
      <ProtectedRoute component={EditProfile} path="/edit-profile" />
      <Route component={Chart} path="/chart" />
      <ProtectedRoute component={RecentTrip} path='/recenttrips' />
      <Route component={DriverDashboard} path='/driver/notification' />
      <Route component={DriverRegister} path='/driver/dashboard' />
      <Route component={Card} path='/card' />
      <Route component={RecentTemplate} path='/hello' />  
      <Route component={DriverSignup} path='/driver/signup' />
      <Route component={SignupUpload} path='/driver/signuppages' />
      <Route component={Upload} path='/upload'/>
      <Route component={AllOffers} path='/offers' />
      <Route component={DisplayOffer} path='/availablerides' />
      {/* <ProtectedRoute component={Dashboard} path="/app"/> */}
       </ThemeContextProvider>
     </Switch>


          

    
     
      
    
  );
}

export default App;
