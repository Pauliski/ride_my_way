import React from 'react';

const RecentTemplate = () => {
    return ( 
        <div style={{backgroundColor: 'blue', height: '160px', width: '80px', margin: '0 auto', position: 'relative'}}>
            <div style={{backgroundColor: 'pink', height: '80px', width: '40px', margin: '0 auto'}}>
                <div style={{backgroundColor: 'yellow', height: '20px', width: '20px', margin: '0 auto', position: 'absolute'}}>

                </div>
            </div>
        </div>
        
     );
}
 
export default RecentTemplate;