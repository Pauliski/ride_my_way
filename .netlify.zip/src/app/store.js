import { configureStore } from '@reduxjs/toolkit'
import userReducer from '../features/passenger/passengerSlice'

export default configureStore({
  reducer: {
    user: userReducer
  }
})