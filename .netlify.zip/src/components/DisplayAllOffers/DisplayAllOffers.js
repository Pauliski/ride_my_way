import React from "react";
import { Rides } from "../../Array";
import DisplayOffer from "../DisplayOffer/DisplayOffer";
import axios from "axios";
import "./DisplayAllOffers.css";

const joinRide = async (id) => {
  let token;
  const response = await axios.post(
    `http://localhost:3000/v1/join-ride/${id}`,
    {},
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  if (response.status === 201) {
    console.log(response.data);
    const token = response.data.signedToken;
    localStorage.setItem("jwtToken", token);
    console.log(token);
    // const decoded = jwt_decode(token);
    // console.log("decoded ===>", decoded)
    // dispatch(currentUser(decoded.data));

    // history.push("/dashboard");
  }
};

function DisplayAllOffers() {
  return (
    <div className="display-all-offers">
      {Rides.map((item) => (
        <DisplayOffer
          name={item.name}
          amount={item.amount}
          location={item.location}
          destination={item.destinations}
          mobile={item.mobile}
          id={item.id}
          joinRide={joinRide}
        />
      ))}
    </div>
  );
}

export default DisplayAllOffers;
