import { navigate } from "@reach/router";
import { useState} from "react";
import validation from './validation'
import { Redirect } from "react-router";

const useForm = (validates) => {
  const defaultValues ={
    firstName: "",
    lastName: "",
    email: "",
    password1: "",
    confirmPassword: "",
    phoneNumber: "",
    plateNumber: "",
    registrationNumber: ""
  }
  // let errors = {}
  const [values, setValues] = useState(defaultValues);
   const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
    

  };
  const handleBlur = (e) => {
    
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
    
    const errorMessages = validates(values)
    setErrors(errorMessages)

  };


  const handleFormSubmit = (event) => {
    // event.preventDefault();
    const errorMessages = validates(values)
    setErrors(errorMessages)
  };
 
 
  console.log(errors)
  return {
    handleChange,
    handleFormSubmit,
    handleBlur,
    values,
    errors,
  };
};
export default useForm;
