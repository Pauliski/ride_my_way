import React, {useState} from 'react'
import { useSelector, useDispatch } from 'react-redux';
import { Input } from '../../element/Input'
import Passport from '../../pictures/pass1.png'
import {updateUser} from '../.../../../store/actions/types/userAction'
import './EditProfileCard.css'


function EditProfileCard() {
    const user = useSelector(state => state.user);
    const [names, setNames] = useState({firstName: user.firstName, lastName: user.lastName})
    const [disabled, setDisabled] = useState(true)
    const [innerText, setInnerText] = useState('Edit')
    const dispatch = useDispatch()

    const handleChange = (e)=>{
        const {name} = e.target
        setNames(prev => {
            return {
                ...prev,
                [name] : e.target.value
            }
        })
    }

    const handleEdit = (e)=>{
       innerText === "Edit" ? setInnerText("Save") : setInnerText("Edit")
         console.log(e.target.innerText)
         
         if(e.target.innerText === "Save") updateUser(names, dispatch)
             
            
         
          console.log(names)
        //  innerText = innerText === "Edit" ? "Save" : "Edit"
        setDisabled(!disabled)
    }
    return (
        <div >
            <div className="profile-container">
                <div className="personal-profile">
                    <div className="card-one">
                        <div className="profile-image-conatiner">
                            <img src={Passport} className="profile-image" alt="" srcset="" />
                        </div>
                        <div className="personal-info-container">
                            <div>Personal info</div>
                            <hr />
                            <div className="personal-info-details">
                                <div className="names">First Name</div>
                                <Input id="profile-input" className={disabled ? '' : 'input-disabled-false'} Value={user.firstName} disabled={disabled} name ="firstName" onChange={handleChange}/>
                            </div>
                            
                        
                        <div className="personal-info-details">
                                <div className="names">Last Name</div>
                                <Input id="profile-input" Value={user.lastName} className={disabled ? '' : 'input-disabled-false'} disabled={disabled} name="lastName"/>
                        </div>
                        <button className="edit-name-button" onClick={handleEdit}>{innerText}</button>
                        </div>
                    </div>
                    <div className="card-two-three-conatiner">
                        <div className="card-two">
                            <div className="contact-info">
                                <div >Contact Information</div>
                                <hr />
                                <div className="contact-info-details">
                                    <div>Email</div>
                                    <button>{user.email}</button>
                                </div>
                                <div className="contact-info-details">
                                    <div>Mobile Number</div>
                                    <button>07023423416</button>
                                </div>
                            </div>
                            
                        </div>
                        <div className="card-three"></div>
                    </div>
                </div>
            </div>
            
        </div>
    )
}

export default EditProfileCard
