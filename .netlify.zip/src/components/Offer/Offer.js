import React from 'react'
import { Input } from '../../element/Input'

import './Offer.css'

function Offer() {
    return (
        <div>
            
            <div className="offer-container">
                <div className="offer">
                    <form action="">
                        Offer
                    <Input />
                    Destinatiom
                    <Input />
                    Amount
                    <Input />
                    <div className="offer-button-container">
                        <button className="offer-button">Edit</button>
                        <button className="offer-button offer-btn">Delete</button>
                    </div>    
                    </form>
                    
                    
                    
                </div>
            </div>
        </div>
    )
}

export default Offer
