import React from 'react'
import { Link } from 'react-router-dom'


function NavLink() {
    return (
        <div>
            <Link></Link>
        </div>
    )
}

export default NavLink
