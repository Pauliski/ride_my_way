import React, {useState} from 'react'
import DisplayAllOffers from '../../components/DisplayAllOffers/DisplayAllOffers'
import DisplayOffer from '../../components/DisplayOffer/DisplayOffer'
import Navbar from '../../components/navbar/navbar'
import Offer from '../../components/Offer/Offer'
import Search from '../../components/Search/Search'
import UserSideBar from '../../components/sidebar/UserSideBar'

function AllOffers() {
    const [sidebarOpen, setsidebarOpen] = useState(false);
    const openSidebar = () => {
        setsidebarOpen(!sidebarOpen);
      };

    return (
        <div className="containe">
            <Navbar sidebarOpen={openSidebar} openSidebar={openSidebar}>
                <Search />
            </Navbar>
            <UserSideBar sidebarOpen={sidebarOpen} closeSidebar={openSidebar}/>
            {/* <Offer /> */}
            <DisplayAllOffers />
        </div>
    )
}

export default AllOffers
