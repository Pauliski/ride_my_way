import jwt_decode from "jwt-decode";
import axios from "axios";
import setAuthToken from "../../../utils/setToken";
import { currentUser, setError, setUserUpdate } from "../../../features/passenger/passengerSlice";

export const RegisterUser = async (userData, dispatch, history) => {
  // const dispatch = useDispatch();
  // console.log(userData, dispatch, history);
  try {
    
    const response = await axios({
      method: "post",
      baseURL: "http://localhost:3000/v1/passenger/register",
      data: userData,
    });
    if (response.status === 201) {
      console.log(response.data)
      const token = response.data.signedToken;
      localStorage.setItem("jwtToken", token);
      console.log(token)
      const decoded = jwt_decode(token);
      console.log("decoded ===>", decoded)
      dispatch(currentUser(decoded.data));

      history.push("/dashboard");
    }
    
  } catch (err) {
    dispatch(setError({error: err.response.data.message}))
    console.log(err.response.data)
  }
};

export const LoginUser = async (userData, dispatch, history) => {
  console.log(userData);
  try {
    const response = await axios({
      method: "post",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      baseURL: "http://localhost:3000/v1/passenger/login",
      data: userData,
    });
    if (!response.ok) {
      const err = await response;
      console.log("failure: ", err);
      // throw new Error(err);
    }
  
    const token = response.data.signedToken;
    const decoded = jwt_decode(token);
    localStorage.setItem("jwtToken", token);
    // localStorage.setItem("user", decoded);
    history.push("/dashboard");
  
    
    console.log("decoded ===>",decoded);
    // setAuthToken(token);
  dispatch(currentUser(decoded.data));
  } catch (error) {
    console.log(error.response.data.message)
  }
  
  
};

export const updateUser = async (names, dispatch)=>{
  // console.log(userData);
  try {
    const token = localStorage.getItem('jwtToken');
  const response = await axios({
    method: "put",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    baseURL: "http://localhost:3000/v1/passenger",
    data: names,
  });
  if (!response.ok) {
    const err = await response;
    console.log("failure: ", err);
    // throw new Error(err);
  }

  // const token = response.data.signedToken;
  // axios.defaults.headers.common['Authorization'] = token;
  const decoded = jwt_decode(token);
  localStorage.setItem("jwtToken", token);
  // localStorage.setItem("user", decoded);


  
  console.log("decoded ===>",decoded);
  // setAuthToken(token);
dispatch(setUserUpdate(decoded.data));
  } catch (error) {
    console.log(error.response.data.message)
  }
  
}